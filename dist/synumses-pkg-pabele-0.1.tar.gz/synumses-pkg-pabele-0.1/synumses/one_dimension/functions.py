import numpy as np

import synumses.one_dimension.parameters as parameters


def calc_p_density():
    
    parameters.p_density = parameters.Nv*np.exp(parameters.q*( parameters.u[1::3] - parameters.u[0::3] + parameters.Ev)/(parameters.kB*parameters.T))
          
    return None



def hole_current_density():
    from twoport.scharfetter_gummel_bernoulli import hole_current_density
        
    print("Use the function hole_current_density() direct from scharfetter_gummel_bernoulli !!")

    return hole_current_density()


def calc_n_density():

    np.save("potential.dat", parameters.u[0::3])
    np.save("fermi_2.dat", parameters.u[2::3])

    parameters.n_density = parameters.Nc*np.exp(parameters.q*( parameters.u[0::3] - parameters.u[2::3] - parameters.Ec)/(parameters.kB*parameters.T))
   
    return None



def electron_current_density():
    from twoport.scharfetter_gummel_bernoulli import electron_current_density
   
    print("Use the function electron_current_density() direct from scharfetter_gummel_bernoulli !!")
    
    return electron_current_density()



def ohm_potential(C, Ec, Ev, Nc, Nv):

    from twoport.parameters import q, kB, Ut, T
        
    ni = np.sqrt(Nc*Nv)*np.exp(-((Ec-Ev)*q)/(2.*kB*T))
    Phi = (Ec + Ev)/2. - 0.5*Ut*np.log(Nc/Nv) + Ut*np.arcsinh(C/(2.*ni))
    #print(Phi)
    
    #if (C > 0):
    #    Phi = Ut*np.log((np.sqrt(C**2 + 4.*ni**2)+C)/(2.*ni))
    #else:
    #    Phi = -Ut*np.log((np.sqrt(C**2 + 4.*ni**2)-C)/(2.*ni))
    # 
    #print(Phi)
    
    return(Phi)


def calc_ni_density():

    parameters.ni_density = (
        np.sqrt(parameters.Nc*parameters.Nv)
        *
        np.exp(-((parameters.Ec-parameters.Ev)*parameters.q)
               /
               (2.*parameters.kB*parameters.T))
    )

    return None

def calc_recombination():
    
    calc_p_density()
    calc_n_density()
    #calc_ni_density()
    np.save("p_density.dat", parameters.p_density)
    np.save("n_density.dat", parameters.n_density)
    parameters.recombination = (
        parameters.Cau
        *
        (parameters.p_density * parameters.n_density -
         parameters.ni_density**2
        )
    )
    
#    parameters.recombination = (
#        (parameters.p_density * parameters.n_density -
#         parameters.ni_density**2
#        )
#        /
#        (parameters.tau_p*parameters.p_density + 
#         parameters.tau_n*parameters.n_density)
#    )

    return None

def calc_generation(I_0, alpha):
    
    return None
    
